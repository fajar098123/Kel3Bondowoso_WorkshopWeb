<?php 
	include_once "checker.php";

	$mysqli = mysqli_connect($db_host, $db_username, "", $db_name);

?>