<a href="http://wa.me/6281515640963?text=Saya Tertarik Untuk Order." 
    target="blank"
        class="float"><p class="my-float">Order Via WA</p></a>