   <!-- Footer -->
   <footer class="page-footer font-small footer">

<!-- Copyright -->
<div class="footer-copyright text-center py-3 footer-text">© 2020 Copyright:
    <a class="text-light" href="https://mdbootstrap.com/">MDBootstrap.com</a> by Kelompok Kita
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->